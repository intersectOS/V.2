-- ══════════════════════════════════════════════
-- INTERSECT PartnerOS - Final Complete Schema
-- Run this in Supabase SQL Editor
-- ══════════════════════════════════════════════

-- Add missing columns to existing tables

-- ix_people: client-facing prices
alter table ix_people add column if not exists rate_hourly_price text;
alter table ix_people add column if not exists rate_monthly_price text;
alter table ix_people add column if not exists rate_yearly_price text;
alter table ix_people add column if not exists username text;
alter table ix_people add column if not exists portal_password text;

-- ix_clients_v2: login credentials
alter table ix_clients_v2 add column if not exists username text;
alter table ix_clients_v2 add column if not exists portal_password text;

-- ix_tasks: link to project properly
alter table ix_tasks add column if not exists project_id text;
alter table ix_tasks add column if not exists updated_at timestamptz default now();

-- ix_projects: add more fields
alter table ix_projects add column if not exists updated_at timestamptz default now();

-- ix_requests: fix client link
alter table ix_requests add column if not exists updated_at timestamptz default now();

-- ix_invoices: add client_id for portal linking
alter table ix_invoices add column if not exists client_id text;

-- ix_news table
create table if not exists ix_news (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  content text not null,
  type text default 'announcement',
  audience text default '["all"]',
  link text,
  published_by text,
  created_at timestamptz default now()
);

-- ix_notifications: email notifications
alter table ix_notifications add column if not exists email_sent boolean default false;
alter table ix_notifications add column if not exists recipient_email text;
alter table ix_notifications add column if not exists recipient_type text;

-- Disable RLS on all tables
alter table ix_people disable row level security;
alter table ix_clients_v2 disable row level security;
alter table ix_workflow disable row level security;
alter table ix_requests disable row level security;
alter table ix_actions disable row level security;
alter table ix_meetings disable row level security;
alter table ix_expert_requests disable row level security;
alter table ix_opportunities disable row level security;
alter table ix_invoices disable row level security;
alter table ix_notifications disable row level security;
alter table ix_projects disable row level security;
alter table ix_tasks disable row level security;
alter table ix_news disable row level security;

-- Grant all to anon
grant usage on schema public to anon;
grant all on all tables in schema public to anon;
grant all on all sequences in schema public to anon;
