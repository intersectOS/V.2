-- INTERSECT PartnerOS Database Schema
-- Run this in Supabase SQL Editor

create table if not exists ix_clients (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  industry text,
  stage text default 'Onboarding',
  email text,
  code text unique not null,
  assigned_to text,
  assigned_expert text,
  notes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists ix_opportunities (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  company text,
  value numeric default 0,
  probability integer default 50,
  stage text default 'New Lead',
  expected_close date,
  assigned_to text,
  assigned_expert text,
  notes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists ix_experts (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  title text,
  country text,
  years integer default 0,
  sectors text,
  code text unique not null,
  availability text default 'Available',
  rating numeric default 5.0,
  created_at timestamptz default now()
);

create table if not exists ix_team (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  role text,
  email text,
  code text unique not null,
  created_at timestamptz default now()
);

create table if not exists ix_meetings (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  organization text,
  date date,
  followup_deadline date,
  attendees text,
  summary text,
  action_items text,
  created_at timestamptz default now()
);

-- Enable RLS
alter table ix_clients enable row level security;
alter table ix_opportunities enable row level security;
alter table ix_experts enable row level security;
alter table ix_team enable row level security;
alter table ix_meetings enable row level security;

-- Public policies (adjust for production security)
create policy "public_all" on ix_clients for all using (true) with check (true);
create policy "public_all" on ix_opportunities for all using (true) with check (true);
create policy "public_all" on ix_experts for all using (true) with check (true);
create policy "public_all" on ix_team for all using (true) with check (true);
create policy "public_all" on ix_meetings for all using (true) with check (true);
